# LAB - 401-lab-29

## RESTy

### Author: Travis Skyles

### Links and Resources

- [submission PR](http://xyz.com)
- [travis](http://xyz.com)
  <!-- * [front-end](http://xyz.com) (when applicable) -->
- [codesandbox.io](https://codesandbox.io/s/resty-41us7)

### Setup

- `clone repo to local`
- `open in editor`
- `npm i`
- `npm start`

#### Tests

- `npm test`

#### UML

![](./assets/RESTy.png)
